function Y = Normalized(X)
% maxX = max(X(:));
% minX = min(X(:));
% Y = (X-minX)/(maxX-minX);

[h,w,c] = size(X);
Y = zeros(h,w,c);
if max(max(max(X)))>1
    for n = 1:c
        maxX = max(max(X(:,:,n)));
        Y(:,:,n) = X(:,:,n)/maxX; 
    end
else
    Y = X;
end

end
    