function [] = VideoShow(D, SaveRoad, speed)
% Visualization of video.
%
% Usage:
% display a video: VideoShow(D, 'output')
%
% by Hailin Wang, TPAMI, 2023.

D = uint8(D);
sizeD  = size(D);
dimD   = length(sizeD);
nframe = sizeD(end);
figure

if nargin < 3
    speed = 0.02;
end

if dimD == 3  
    for i = 1:nframe       
        imshow(abs(D(:,:,i)))  ;
        
        frame = getframe;
        im = frame2im(frame);
        [I,map] = rgb2ind(im,256);
        pause(1/24);
        if 1 == i
            imwrite(I,map,[SaveRoad '.gif'],'gif','Loopcount',inf,'DelayTime',speed);
        else
            imwrite(I,map,[SaveRoad '.gif'],'gif','WriteMode','append','DelayTime',speed);
        end        
    end
    
else
    for i = 1:nframe        
        imshow(abs(D(:,:,:,i)))  ;
        
        frame = getframe;
        im = frame2im(frame);
        [I,map] = rgb2ind(im,256);
        pause(1/24);
        if 1 == i
            imwrite(I,map,[SaveRoad '.gif'],'gif','Loopcount',inf,'DelayTime',speed);
        else
            imwrite(I,map,[SaveRoad '.gif'],'gif','WriteMode','append','DelayTime',speed);
        end      
    end
    
end

end