function ImgRGB = RGBImage(MSI, slected_bands)

msi_sz  =  size(MSI);
ImgRGB = zeros(msi_sz(1), msi_sz(2), 3);
ImgRGB(:,:,1) = MSI(:,:,slected_bands(1));
ImgRGB(:,:,2) = MSI(:,:,slected_bands(2));
ImgRGB(:,:,3) = MSI(:,:,slected_bands(3));

end