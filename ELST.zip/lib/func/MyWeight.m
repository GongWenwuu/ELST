function w_n = MyWeight(X, mode, Para)
% Compute the weights of factor matrices
% Inputs:
% X - input data or factor matrix
% mode - n-th factor
% Para - type of weight determination to use
%
% Outputs:
% w_n - factor matrix weight
if strcmp(Para,'lrstd')
    N = length(X);
    sValue = cell(1,N-1); Unorm = ones(1,N-1);
    indices = 1:N;
    indices(mode) = [];
    for n = indices
        sValue{n} = svd(X{n}, 'econ');
        Unorm(n)  = sum(sValue{n});
    end
    w_n = prod(Unorm);
elseif strcmp(Para,'prod')
    N = length(X);
    sValue = cell(1,N-1); Unormexcep = ones(1,N-1);
    indices = 1:N;
    indices(mode) = [];
    for n = indices
        sValue{n} = svd(X{n}, 'econ');
        Unormexcep(n)  = sum(sValue{n});
    end
    w_n = prod(Unormexcep)/Usum(X);
elseif strcmp(Para,'sum')
    N = ndims(X);
    sigma = cell(1,N); Xnorm = 0;
    for n = 1:N
        Xn  = reshape(permute(X, [n 1:n-1 n+1:N]),size(X,n),[]);
        sigma{n} = svd(Xn, 'econ');
        Xnorm  = Xnorm + sum(sigma{n}>eps);
    end
    Xn  = reshape(permute(X, [mode 1:mode-1 mode+1:N]),size(X,mode),[]);
    w_n = sum(svd(Xn, 'econ'))/Xnorm;
else
    w_n = 1/3;
end

end

function Usum = Usum(U)
N = length(U); Unorm = ones(1,N);
for n = 1:N
    sigma = cell(1,N-1); temp = ones(1,N-1);
    indices = 1:N;
    indices(n) = [];
    for i = indices
        sigma{i} = svd(U{i}, 'econ');
        temp(i) = sum(sigma{i});
    end
    Unorm(n) = prod(temp);
end
Usum = sum(Unorm);
end