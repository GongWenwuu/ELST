function X = Proximal(Xk,grad,Lip,alpha,Opts)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% X = arg min { alpha*|| X ||_Opts + <grad(Xk),X-Xk> + (Lip/2)*(|| X-Xk ||_F)^2 } 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
if strcmp(Opts,'tr')
    X = tracenorm(Xk-grad/(Lip), alpha/Lip);
elseif strcmp(Opts,'l1')
    X = thresholding(Xk-grad/(Lip), alpha/Lip);
else
    error('Parameter is wrong');
end

end

function X = tracenorm(Z, tau)

    [U,S,V] = svd(Z,'econ');
    S = diag(S);
    rank = sum(S > tau);
    X = U(:,1:rank)*diag(S(1:rank)-tau)*V(:,1:rank)';

end

function X = thresholding(Z, tau)

    A_sign = sign(Z);
    X = abs(Z) - tau;
    X(X < 0) = 0;
    X = X .* A_sign;
    
end