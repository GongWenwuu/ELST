function [L, T, gamma, flag] = LocalPrior(X, R, Para, prior)
% Compute constant matrices which serve as the role of characterizing the feature of the X
% Inputs:
% X - input data
% Para - boolean or array indicats the spatiotemporal form
% prior - type of regularization to use ('lrstd', 'stdc' or 'teo') for spatiotemporal property
%
% Outputs:
% gamma - regularization parameters
% L - cell array of Laplacian matrices
% T - cell array of transform matrices

N = ndims(X);
gamma = zeros(1, N);
L = cell(1, N); H = L;
T = cell(1, N);

if isempty(Para)
    flag = 2.*ones(1, N);
else
    flag = Para;
    for n = 1:N
        Xmat = reshape(permute(X, [n 1:n-1 n+1:N]), size(X, n), []);
        if flag(n) == 1
            if strcmp(prior, 'stdc')
                L = ConstructL_stdc(size(X), {1, 2, 3}, 2, L);
            elseif strcmp(prior, 'lrstd')
                L = ConstructL_lrstd(X, 5, 0);
            elseif strcmp(prior, 'teo')
                H{n} = ConstructT(R(n));
                L{n} = H{n}'*H{n};
            end
            gamma(n) = norm(Xmat, 2)/(2*norm(L{n}, 2));
        elseif flag(n) == 0
            if strcmp(prior, 'teo')
                T{n} = ConstructT(R(n));
            elseif strcmp(prior, 'lrstd')
                T{n} = zeros(R(n)-1,R(n));
                for i = 1:R(n)-2
                    T{n}(i,i) = 1;
                    T{n}(i,i+1) = -2;
                    T{n}(i,i+2) = 1;
                end
            end
            gamma(n) = norm(Xmat, 2)/(2*norm(T{n}'*T{n}, 2));
        else
            gamma(n) = 0;
        end
    end
end

end