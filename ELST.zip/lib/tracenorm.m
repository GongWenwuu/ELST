function [X, rank, S] = tracenorm(Z, tau)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       min: 1/2*||Z-X||^2 + tau ||X||_*
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% \mathcal{D}_{\tau}(Z) = U \mathcal{D}_{\tau}(\Sigma) V',  \mathcal{D}_{\tau}(\Sigma)=max(diag(\sigma_{i})-\tau,0)

    [U,S,V] = svd(Z,'econ');
    S = diag(S);
    rank = sum(S > tau);
    X = U(:,1:rank)*diag(S(1:rank)-tau)*V(:,1:rank)';

end